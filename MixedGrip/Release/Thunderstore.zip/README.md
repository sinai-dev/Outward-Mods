## Mixed Grip

Allows you to swap between 1H and 2H grip on Melee Weapons, similar to Dark Souls.

Set a keybinding in your in-game keybindings for the grip toggle, and adjust the BepInEx config as you desire.

The config can be managed through the [Configuration Manager](https://github.com/Mefino/BepInEx.ConfigurationManager), or by editing the file at `BepInEx\config\com.sinai.mixedgrip.cfg`.