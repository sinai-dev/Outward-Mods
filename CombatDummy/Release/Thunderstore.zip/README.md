## Combat Dummy
This mod allows you to spawn customizable Combat Dummies, either for testing builds and damage or practicing your combat skills against their AI.

* In order to use the Combat Dummy menu, load up a Character and set a keybinding for the Combat Dummy Menu in your in-game keybinding settings.
* Once you have loaded a character and set the keybinding, press it to open the menu and start practicing / testing against dummies. There is no limit to how many you can spawn at once.
* There is quite a bit of freedom in what you can set on the dummy, including making it an Ally or Enemy, setting its weapon, etc.