## More Map Details

More Map Details adds some extra details to the region maps, all of which can be toggled. The extra details include:

* Player positions
* Player bag positions
* Enemy positions (the markers show as an 'X' until you hover over them)
* Soroborean Caravanner position

The config can be managed through the [Config Manager](https://outward.thunderstore.io/package/Mefino/Outward_Config_Manager/), or the r2modman Config Editor, or by editing the file at `BepInEx\config\com.sinai.moremapdetails.cfg`.