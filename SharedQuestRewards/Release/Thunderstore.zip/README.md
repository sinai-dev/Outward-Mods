## Shared Quest Rewards

This mod attempts to share all quest rewards (skills and items).

**Note:** by default, the "aggressive sharing" mode is disabled. If you want you can enable the aggressive sharing in the config, it will try to share absolutely everything but this may lead to sharing some unexpected things (eg, buying a skill from a side-trainer may be shared, etc).

The config can be managed with the [Config Manager](https://outward.thunderstore.io/package/Mefino/Outward_Config_Manager/), or by editing the file at "BepInEx\config\com.sinai.sharedquestrewards.cfg".