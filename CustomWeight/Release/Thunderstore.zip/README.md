## Custom Weight

This Custom Weight mod allows you to:

* Set custom Pouch Bonus (flat value)
* Set custom Bag Bonus (flat AND multiplier values)
* Set No Limits on all containers
* Remove all Weight Burdens

The config can be managed through the [Config Manager](https://outward.thunderstore.io/package/Mefino/Outward_Config_Manager/), or the r2modman Config Editor, or by editing the file at `BepInEx\config\com.sinai.customweight.cfg`.