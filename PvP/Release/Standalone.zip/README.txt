This release includes PvP v2.5 and BepInEx 5.3.

To install:

	0. First, make sure you are on the Mono branch of Outward. Details here:
	   https://outward.gamepedia.com/Installing_Mods#Modding_Branch

	1. Open the 'Put all this in the Outward folder' folder

	2. Select everything (1 folder and 2 files) and Copy or Cut them

	3. Go to the Outward install folder (eg. Steam\steamapps\common\Outward\)

	4. Paste (ctrl+v)

	5. It should look like 'Outward\BepInEx\', and 2 files in the base Outward folder 'winhttp.dll' and 'doorstop_config.ini'.


To uninstall:

	1. Delete or remove the BepInEx folder and the two files from your Outward folder.